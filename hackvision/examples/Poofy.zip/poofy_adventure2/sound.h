#ifndef __SOUND__
#define __SOUND__

void sound_play_song(char song);
void sound_play_song_once(char song);
void sound_update();
void sound_play_sfx(char song);

#endif __SOUND__
