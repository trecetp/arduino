#ifndef LEVEL_BITMAP_H
#define LEVEL_BITMAP_H

#include <avr/pgmspace.h>

extern prog_uchar level_bitmap[];

#endif