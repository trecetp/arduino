#ifndef POOFY_BITMAP_H
#define POOFY_BITMAP_H

#include <avr/pgmspace.h>

extern prog_uchar poofy_bitmap[];

#endif