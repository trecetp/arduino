#ifndef __SNAKE__
#define __SNAKE__
#include "room.h"

RoomElement snake_move(RoomElement element);
RoomElement snake_hit(RoomElement element);

#endif __SNAKE__
