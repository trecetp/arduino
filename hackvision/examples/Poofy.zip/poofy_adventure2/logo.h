#ifndef __LOGO__
#define __LOGO__

void logo_draw();

#endif __LOGO__
