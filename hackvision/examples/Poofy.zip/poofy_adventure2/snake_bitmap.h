#ifndef SNAKE_BITMAP_H
#define SNAKE_BITMAP_H

#include <avr/pgmspace.h>

extern prog_uchar snake_bitmap[];

#endif