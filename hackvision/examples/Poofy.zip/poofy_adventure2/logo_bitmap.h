#ifndef LOGO_BITMAP_H
#define LOGO_BITMAP_H

#include <avr/pgmspace.h>

extern prog_uchar logo_bitmap[];

#endif