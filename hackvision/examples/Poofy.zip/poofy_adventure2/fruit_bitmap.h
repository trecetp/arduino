#ifndef FRUIT_BITMAP_H
#define FRUIT_BITMAP_H

#include <avr/pgmspace.h>

extern prog_uchar fruit_bitmap[];

#endif