#ifndef __FRUIT__
#define __FRUIT__
#include "room.h"

void fruit_draw(RoomElement element);
RoomElement fruit_hit(RoomElement element);

#endif __FRUIT__
