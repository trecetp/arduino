#ifndef __DISPLAY__
#define __DISPLAY__

void display_update(unsigned int add_to_score);
void display_init();

#endif __DISPLAY__
